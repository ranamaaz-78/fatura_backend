<?php

$local = [
    'http://localhost:5173',
    'http://127.0.0.1:5173',
    'capacitor://localhost',
    'https://localhost',
    'http://localhost',
];

$frontend = rtrim((string) env('FRONTEND_URL', ''), '/');

$extra = array_map(
    static fn (string $origin) => rtrim(trim($origin), '/'),
    explode(',', (string) env('CORS_ALLOWED_ORIGINS', '')),
);

return [

    'paths' => ['api/*', 'sanctum/csrf-cookie'],

    'allowed_methods' => ['*'],

    'allowed_origins' => array_values(array_unique(array_filter([
        ...$local,
        $frontend,
        ...$extra,
    ]))),

    'allowed_origins_patterns' => [],

    'allowed_headers' => ['*'],

    'exposed_headers' => [],

    'max_age' => 0,

    'supports_credentials' => false,

];
