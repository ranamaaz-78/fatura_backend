<?php echo e($slot); ?>

<?php /**PATH D:\fatura\fatura_backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/panel.blade.php ENDPATH**/ ?>