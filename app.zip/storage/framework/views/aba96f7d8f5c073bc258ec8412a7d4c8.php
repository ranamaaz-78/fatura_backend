<?php
    $locale = $invoice->locale;
    $money = fn ($value) => \App\Support\Fmt::currency((float) $value, $invoice->currency, $locale);
    $day = fn ($value) => $value ? \Illuminate\Support\Carbon::parse($value)->locale($locale)->isoFormat('D MMM YYYY') : '';

    $to = $invoice->data['billed_to'];
    $plan = $invoice->data['plan'];
    $coverage = $invoice->data['coverage'];
    $payment = $invoice->data['payment'];
    $interval = $plan['interval'];

    $words = match ($interval) {
        'year' => ['qty' => __('Years'), 'unit' => __('Price / year'), 'cycle' => __('yearly')],
        'quarter' => ['qty' => __('Quarters'), 'unit' => __('Price / quarter'), 'cycle' => __('quarterly')],
        default => ['qty' => __('Months'), 'unit' => __('Price / month'), 'cycle' => __('monthly')],
    };
    $periodNote = match ($interval) {
        'year' => __('(1 period = 1 year)'),
        'quarter' => __('(1 period = 1 quarter)'),
        default => __('(1 period = 1 month)'),
    };
?>
<!DOCTYPE html>
<html lang="<?php echo e($locale); ?>">
<head>
<meta charset="utf-8">
<title><?php echo e($invoice->number); ?></title>
<style>
    @page { size: A4; margin: 0; }
    body { margin: 0; font-family: 'DejaVu Sans', sans-serif; color: #0b1c30; font-size: 9.5pt; }
    table { border-collapse: collapse; }
    .muted { color: #64748b; }
    .label { font-size: 7pt; letter-spacing: 1px; text-transform: uppercase; color: #64748b; font-weight: bold; }
    .txt { font-size: 8.8pt; line-height: 1.6; color: #475569; }
    .name { font-size: 11pt; font-weight: bold; margin-bottom: 3px; }
    .th { font-size: 7pt; letter-spacing: 1px; text-transform: uppercase; color: #64748b; padding: 8px 0; border-bottom: 2px solid #0b1c30; text-align: left; }
    .td { padding: 14px 0; border-bottom: 1px solid #e5eeff; vertical-align: top; font-size: 9.5pt; }
    .r { text-align: right; }
    .box { border: 1px solid #e5eeff; padding: 12px 14px; vertical-align: top; }
</style>
</head>
<body>


<table width="100%" bgcolor="#0b1c30" style="background-color:#0b1c30;">
    <tr>
        <td style="padding:38px 46px 30px 46px;" valign="top">
            <img src="<?php echo e($logo); ?>" alt="<?php echo e($issuer['name']); ?>" style="height:38px;">
        </td>
        <td style="padding:38px 46px 30px 46px; text-align:right; color:#ffffff;" valign="top">
            <div style="font-size:8pt; letter-spacing:2px; text-transform:uppercase; color:#cbd5e1; font-weight:bold;"><?php echo e(__('Invoice')); ?></div>
            <div style="font-size:18pt; font-weight:bold; margin-top:3px;"><?php echo e($invoice->number); ?></div>
        </td>
    </tr>
</table>

<div style="padding:28px 46px 0 46px;">

    
    <table width="100%">
        <tr>
            <td width="50%" valign="top" style="padding-right:20px;">
                <div class="label"><?php echo e(__('Issued by')); ?></div>
                <div class="name" style="margin-top:5px;"><?php echo e($issuer['name']); ?></div>
                <div class="txt">
                    <?php if(filled($issuer['tax_id'])): ?> NIF/CIF: <?php echo e($issuer['tax_id']); ?><br><?php endif; ?>
                    <?php if(filled($issuer['address'])): ?> <?php echo e($issuer['address']); ?><br><?php endif; ?>
                    <?php echo e($support['email']); ?><br>
                    <?php echo e($support['whatsapp']); ?>

                </div>
            </td>
            <td width="50%" valign="top">
                <div class="label"><?php echo e(__('Billed to')); ?></div>
                <div class="name" style="margin-top:5px;"><?php echo e($to['name']); ?></div>
                <div class="txt">
                    <?php if(filled($to['tax_id'])): ?> NIF/CIF: <?php echo e($to['tax_id']); ?><br><?php endif; ?>
                    <?php if(filled($to['address'])): ?> <?php echo e($to['address']); ?><br><?php endif; ?>
                    <?php echo e($to['email']); ?>

                </div>
            </td>
        </tr>
    </table>

    
    <table width="100%" style="margin-top:22px; border:1px solid #e5eeff;">
        <tr>
            <td width="30%" style="padding:10px 14px; border-right:1px solid #e5eeff;">
                <div class="label"><?php echo e(__('Issue date')); ?></div>
                <div style="font-size:10pt; font-weight:bold; margin-top:3px;"><?php echo e($day($invoice->issued_at)); ?></div>
            </td>
            <td width="43%" style="padding:10px 14px; border-right:1px solid #e5eeff;">
                <div class="label"><?php echo e(__('Service period')); ?></div>
                <div style="font-size:10pt; font-weight:bold; margin-top:3px;"><?php echo e($day($coverage['from'])); ?> – <?php echo e($day($coverage['to'])); ?></div>
            </td>
            <td width="27%" style="padding:10px 14px;">
                <div class="label"><?php echo e(__('Status')); ?></div>
                <div style="margin-top:3px;">
                    <?php if($invoice->isPaid()): ?>
                        <span style="background:#e6f9f1; color:#007d55; font-weight:bold; font-size:9pt; padding:2px 9px;"><?php echo e(__('Paid')); ?></span>
                    <?php else: ?>
                        <span style="background:#fff4e0; color:#b45309; font-weight:bold; font-size:9pt; padding:2px 9px;"><?php echo e(__('Pending')); ?></span>
                    <?php endif; ?>
                </div>
            </td>
        </tr>
    </table>

    
    <table width="100%" style="margin-top:24px;">
        <tr>
            <td class="th" width="46%"><?php echo e(__('Description')); ?></td>
            <td class="th r" width="14%"><?php echo e($words['qty']); ?></td>
            <td class="th r" width="20%"><?php echo e($words['unit']); ?></td>
            <td class="th r" width="20%"><?php echo e(__('Amount')); ?></td>
        </tr>
        <tr>
            <td class="td">
                <div style="font-weight:bold;"><?php echo e(__('Subscription — :plan plan', ['plan' => $plan['name']])); ?></div>
                <div class="muted" style="font-size:8.3pt; margin-top:3px; line-height:1.5;"><?php echo e(__('Access to the invoicing and stock management platform')); ?></div>
            </td>
            <td class="td r"><?php echo e($invoice->periods); ?></td>
            <td class="td r"><?php echo e($money($invoice->unit_price)); ?></td>
            <td class="td r"><?php echo e($money($invoice->total)); ?></td>
        </tr>
    </table>

    
    <table width="100%" style="margin-top:18px;">
        <tr>
            <td width="55%"></td>
            <td width="45%" bgcolor="#eff4ff" style="background-color:#eff4ff; padding:12px 16px;">
                <table width="100%">
                    <tr>
                        <td style="font-weight:bold; font-size:10pt;"><?php echo e(__('Total')); ?></td>
                        <td class="r" style="font-weight:bold; font-size:17pt; color:#004ac6;"><?php echo e($money($invoice->total)); ?></td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>

    
    <table width="100%" style="margin-top:26px;">
        <tr>
            <td width="49%" class="box">
                <div class="label"><?php echo e(__('Payment')); ?></div>
                <div class="txt" style="margin-top:5px;">
                    <?php if($payment): ?>
                        <?php if(filled($payment['method'])): ?><b style="color:#0b1c30;"><?php echo e(__('Method')); ?></b>: <?php echo e($payment['method']); ?><br><?php endif; ?>
                        <?php if(filled($payment['reference'])): ?><b style="color:#0b1c30;"><?php echo e(__('Reference')); ?></b>: <?php echo e($payment['reference']); ?><br><?php endif; ?>
                        <b style="color:#0b1c30;"><?php echo e(__('Paid on')); ?></b>: <?php echo e($day($payment['paid_at'])); ?>

                    <?php else: ?>
                        <?php echo e(__('This invoice is pending payment. Write to us to arrange it.')); ?>

                    <?php endif; ?>
                </div>
            </td>
            <td width="2%"></td>
            <td width="49%" class="box">
                <div class="label"><?php echo e(__('Subscription')); ?></div>
                <div class="txt" style="margin-top:5px;">
                    <b style="color:#0b1c30;"><?php echo e(__('Plan')); ?></b>: <?php echo e($plan['name']); ?> · <?php echo e($words['cycle']); ?><br>
                    <b style="color:#0b1c30;"><?php echo e(__('Periods')); ?></b>: <?php echo e($invoice->periods); ?> <?php echo e($periodNote); ?><br>
                    <b style="color:#0b1c30;"><?php echo e(__('Next renewal')); ?></b>: <?php echo e($day($coverage['to'])); ?>

                </div>
            </td>
        </tr>
    </table>
</div>


<div style="position:absolute; left:0; right:0; bottom:0; border-top:1px solid #e5eeff; padding:14px 46px 22px 46px;">
    <table width="100%">
        <tr>
            <td class="muted" style="font-size:8pt; line-height:1.6;">
                <b style="color:#334155;"><?php echo e($issuer['name']); ?></b><br><?php echo e(__('Thank you for trusting us.')); ?>

            </td>
            <td class="muted r" style="font-size:8pt; line-height:1.6;">
                <?php echo e(__('Questions about this invoice?')); ?><br><b style="color:#334155;"><?php echo e($support['email']); ?> · <?php echo e($support['whatsapp']); ?></b>
            </td>
        </tr>
    </table>
</div>

</body>
</html>
<?php /**PATH D:\fatura\fatura_backend\resources\views/billing/invoice-pdf.blade.php ENDPATH**/ ?>