<?php
    $waDigits = preg_replace('/\D+/', '', (string) $supportWhatsapp);
?>


<?php $__env->startSection('title', __('Renewal reminder')); ?>
<?php $__env->startSection('preview', __('Your :plan subscription ends on :date. Renew to keep your account active.', ['plan' => $subscription->plan_name, 'date' => $subscription->ends_at->toFormattedDateString()])); ?>
<?php $__env->startSection('dot', '#f59e0b'); ?>
<?php $__env->startSection('eyebrow', __('Renewal reminder')); ?>
<?php $__env->startSection('heading'); ?>
    <?php echo e(__('Your subscription ends in')); ?><br><span style="color:#4edea3;"><?php echo e($daysLeft); ?> <?php echo e(__('day(s)')); ?>.</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <p style="margin:0 0 6px 0;font-size:16px;font-weight:700;color:#0b1c30;"><?php echo e(__('Hi :name,', ['name' => $owner->name])); ?></p>
    <p style="margin:0 0 24px 0;">
        <?php echo e(__('The :plan subscription for :company ends on :date — that is :days day(s) from now.', [
            'plan' => $subscription->plan_name,
            'company' => $company->name,
            'date' => $subscription->ends_at->toFormattedDateString(),
            'days' => $daysLeft,
        ])); ?>

    </p>

    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#eff4ff" style="background-color:#eff4ff;border:1px solid #dbe1ff;border-radius:14px;">
        <tr>
            <td style="padding:18px 20px;">
                <div style="font-size:11.5px;letter-spacing:.08em;text-transform:uppercase;font-weight:700;color:#004ac6;"><?php echo e(__('Your plan')); ?></div>
                <div style="margin-top:6px;font-size:18px;font-weight:800;letter-spacing:-.01em;color:#0b1c30;"><?php echo e($subscription->plan_name); ?></div>
                <div style="margin-top:4px;font-size:13.5px;color:#434655;"><?php echo e(__('Ends on :date', ['date' => $subscription->ends_at->toFormattedDateString()])); ?></div>
            </td>
        </tr>
    </table>

    <p style="margin:28px 0 14px 0;"><?php echo e(__('To keep your account active, contact us to renew:')); ?></p>

    <table role="presentation" cellpadding="0" cellspacing="0" border="0">
        <tr>
            <td align="center" bgcolor="#004ac6" style="background-color:#004ac6;border-radius:12px;">
                <a href="mailto:<?php echo e($supportEmail); ?>" style="display:inline-block;padding:15px 28px;font-family:'Geist','Segoe UI',Helvetica,Arial,sans-serif;font-size:15px;font-weight:600;color:#ffffff;text-decoration:none;border-radius:12px;"><?php echo e(__('Email us')); ?></a>
            </td>
            <?php if($waDigits !== ''): ?>
                <td width="12" style="width:12px;font-size:0;">&nbsp;</td>
                <td align="center" style="border:1.5px solid #004ac6;border-radius:12px;">
                    <a href="https://wa.me/<?php echo e($waDigits); ?>" style="display:inline-block;padding:13.5px 26px;font-family:'Geist','Segoe UI',Helvetica,Arial,sans-serif;font-size:15px;font-weight:600;color:#004ac6;text-decoration:none;border-radius:12px;"><?php echo e(__('WhatsApp')); ?></a>
                </td>
            <?php endif; ?>
        </tr>
    </table>
    <p style="margin:14px 0 0 0;font-size:13px;color:#6b7280;">
        <?php echo e($supportEmail); ?><?php if($waDigits !== ''): ?> &nbsp;·&nbsp; <?php echo e($supportWhatsapp); ?><?php endif; ?>
    </p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('mail.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\fatura\fatura_backend\resources\views/mail/subscription-expiring.blade.php ENDPATH**/ ?>