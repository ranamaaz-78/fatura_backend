<?php

namespace Tests\Feature;

use App\Models\Company;
use App\Models\CompanyPaymentMethod;
use App\Models\Product;
use App\Models\Subscription;
use App\Models\Supplier;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ReportTest extends TestCase
{
    use RefreshDatabase;

    private Company $company;

    private User $owner;

    protected function setUp(): void
    {
        parent::setUp();

        $this->company = Company::factory()->create();
        Subscription::factory()->create(['company_id' => $this->company->id]);
        $this->owner = User::factory()->businessAdmin()->create(['company_id' => $this->company->id]);
    }

    public function test_sales_excludes_quotes_and_voided_documents(): void
    {
        $this->issuePaid('factura', 'Adeel');
        $this->issuePending('factura', 'Walk-in');
        $this->issue('quotation', 'Quote client');

        $voided = $this->issuePaid('factura', 'Returned');
        $this->actingAs($this->owner, 'sanctum')
            ->postJson('/api/app/sales/'.$voided.'/void', ['reason' => 'Client returned the order'])
            ->assertOk();

        $this->actingAs($this->owner, 'sanctum')
            ->getJson('/api/app/reports/sales')
            ->assertOk()
            ->assertJsonPath('data.kind', 'sales')
            ->assertJsonPath('data.kpis.document_count', 2)
            ->assertJsonPath('data.kpis.total_cents', 1210 * 2)
            ->assertJsonPath('data.kpis.paid_cents', 1210)
            ->assertJsonPath('data.kpis.outstanding_cents', 1210);
    }

    public function test_sales_respects_a_custom_date_range(): void
    {
        $this->issuePaid('factura', 'Today', ['issued_at' => now()->toIso8601String()]);
        $this->issuePaid('factura', 'Last month', ['issued_at' => now()->subMonthNoOverflow()->endOfMonth()->toIso8601String()]);

        $from = now()->subMonthNoOverflow()->endOfMonth()->toDateString();
        $to = $from;

        $this->actingAs($this->owner, 'sanctum')
            ->getJson("/api/app/reports/sales?period=custom&from={$from}&to={$to}")
            ->assertOk()
            ->assertJsonPath('data.kpis.document_count', 1)
            ->assertJsonPath('data.kpis.paid_cents', 1210);
    }

    public function test_tax_is_grouped_by_rate(): void
    {
        $this->issuePaid('factura', 'Adeel');
        $this->issuePaid('albaran', 'Goppal');

        $this->actingAs($this->owner, 'sanctum')
            ->getJson('/api/app/reports/tax')
            ->assertOk()
            ->assertJsonPath('data.kpis.tax_cents', 210)
            ->assertJsonPath('data.kpis.base_cents', 2000)
            ->assertJsonCount(2, 'data.rows');
    }

    public function test_best_sellers_sum_quantities_from_sale_lines(): void
    {
        $shirt = Product::factory()->create([
            'company_id' => $this->company->id,
            'article' => 'Cotton shirt',
            'quantity' => 20,
        ]);
        $this->issuePaid('factura', 'Adeel', [
            'lines' => [[
                'product_id' => $shirt->id,
                'article' => 'Cotton shirt',
                'quantity' => 3,
                'unit_price' => 1000,
                'discount_percent' => 0,
                'iva_percent' => 21,
            ]],
        ]);

        $this->actingAs($this->owner, 'sanctum')
            ->getJson('/api/app/reports/products')
            ->assertOk()
            ->assertJsonPath('data.kpis.product_count', 1)
            ->assertJsonPath('data.kpis.quantity', 3)
            ->assertJsonPath('data.rows.0.article', 'Cotton shirt')
            ->assertJsonPath('data.rows.0.quantity', 3);
    }

    public function test_products_sold_lists_every_product_with_barcode_brand_average_and_stock_left(): void
    {
        $shirt = Product::factory()->create(['company_id' => $this->company->id, 'article' => 'Cotton shirt', 'barcode' => '8431234567893', 'brand' => 'Levis', 'quantity' => 20]);
        $hat = Product::factory()->create(['company_id' => $this->company->id, 'article' => 'Straw hat', 'barcode' => '8431234567800', 'brand' => null, 'quantity' => 5]);
        $unsold = Product::factory()->create(['company_id' => $this->company->id, 'article' => 'Never sold', 'quantity' => 9]);

        $line = fn (Product $product, int $quantity) => [
            'product_id' => $product->id,
            'article' => $product->article,
            'quantity' => $quantity,
            'unit_price' => 1000,
            'discount_percent' => 0,
            'iva_percent' => 21,
        ];
        $this->issuePaid('factura', 'Adeel', ['lines' => [$line($shirt, 3), $line($hat, 1)]]);
        $this->issuePaid('factura', 'Goppal', ['lines' => [$line($shirt, 2)]]);

        $report = $this->actingAs($this->owner, 'sanctum')->getJson('/api/app/reports/sold')->assertOk();

        $report->assertJsonPath('data.kind', 'sold')
            ->assertJsonPath('data.kpis.product_count', 2)
            ->assertJsonPath('data.kpis.quantity', 6);

        $rows = collect($report->json('data.rows'))->keyBy('article');
        $this->assertSame(['Cotton shirt', 'Straw hat'], $rows->keys()->all(), 'most pieces first, and what never sold is not there');
        $this->assertSame('8431234567893', $rows['Cotton shirt']['barcode']);
        $this->assertSame('Levis', $rows['Cotton shirt']['brand']);
        $this->assertSame(5, $rows['Cotton shirt']['quantity']);
        $this->assertSame(2, $rows['Cotton shirt']['document_count']);
        $this->assertSame(1210, $rows['Cotton shirt']['avg_price_cents'], '1 000 + 21 % tax per piece');
        $this->assertSame(6050, $rows['Cotton shirt']['total_cents']);
        $this->assertSame(15, $rows['Cotton shirt']['stock'], '20 in stock, 5 sold');
        $this->assertNull($rows['Straw hat']['brand']);
        $this->assertNotContains('Never sold', $rows->keys()->all());
        $this->assertSame(9, $unsold->fresh()->quantity);

        // A voided document sells nothing.
        $this->actingAs($this->owner, 'sanctum')->getJson('/api/app/reports/sold?period=custom&from=2000-01-01&to=2000-01-31')->assertOk()->assertJsonPath('data.kpis.product_count', 0);
    }

    public function test_outstanding_lists_open_documents(): void
    {
        $this->issuePaid('factura', 'Adeel');
        $this->issuePending('factura', 'Walk-in');

        $this->actingAs($this->owner, 'sanctum')
            ->getJson('/api/app/reports/outstanding')
            ->assertOk()
            ->assertJsonPath('data.kpis.document_count', 1)
            ->assertJsonPath('data.kpis.outstanding_cents', 1210)
            ->assertJsonPath('data.rows.0.client_name', 'Walk-In');
    }

    public function test_payments_group_received_cents_by_method(): void
    {
        $this->issuePaid('factura', 'Adeel');
        $this->issuePaid('factura', 'Goppal', ['payment_method_id' => $this->cardId()]);
        $this->issuePending('factura', 'Walk-in');

        $this->actingAs($this->owner, 'sanctum')
            ->getJson('/api/app/reports/payments')
            ->assertOk()
            ->assertJsonPath('data.kpis.document_count', 3)
            ->assertJsonPath('data.kpis.received_cents', 2420);

        $names = collect($this->actingAs($this->owner, 'sanctum')
            ->getJson('/api/app/reports/payments')
            ->json('data.rows'))
            ->pluck('method_name')
            ->all();

        $this->assertContains('Cash', $names);
        $this->assertContains('Card', $names);
        $this->assertContains(null, $names);
    }

    public function test_stock_value_uses_buying_price_cents(): void
    {
        Product::factory()->create([
            'company_id' => $this->company->id,
            'quantity' => 4,
            'buying_price' => 250,
            'minimum_stock' => 1,
        ]);
        Product::factory()->lowStock()->create([
            'company_id' => $this->company->id,
            'article' => 'Low lamp',
            'buying_price' => 100,
        ]);
        Product::factory()->outOfStock()->create([
            'company_id' => $this->company->id,
            'buying_price' => 999,
        ]);

        $payload = $this->actingAs($this->owner, 'sanctum')
            ->getJson('/api/app/reports/stock')
            ->assertOk()
            ->assertJsonPath('data.kpis.product_count', 3)
            ->assertJsonPath('data.kpis.ok_count', 1)
            ->assertJsonPath('data.kpis.low_count', 1)
            ->assertJsonPath('data.kpis.out_count', 1)
            ->assertJsonPath('data.kpis.stock_value_cents', 4 * 250 + 2 * 100)
            ->json('data.rows');

        $low = collect($payload)->firstWhere('article', 'Low lamp');
        $this->assertNotNull($low);
        $this->assertSame('low', $low['band']);
    }

    public function test_clients_rank_sales_in_the_period(): void
    {
        $this->issuePaid('factura', 'Adeel');
        $this->issuePaid('factura', 'Adeel');
        $this->issuePending('factura', 'Walk-in');

        $this->actingAs($this->owner, 'sanctum')
            ->getJson('/api/app/reports/clients')
            ->assertOk()
            ->assertJsonPath('data.kpis.client_count', 2)
            ->assertJsonPath('data.rows.0.client_name', 'Adeel')
            ->assertJsonPath('data.rows.0.document_count', 2)
            ->assertJsonPath('data.rows.0.total_cents', 2420)
            ->assertJsonPath('data.rows.1.client_name', 'Walk-In')
            ->assertJsonPath('data.rows.1.outstanding_cents', 1210);
    }

    public function test_suppliers_sum_catalog_stock_value(): void
    {
        $acme = Supplier::factory()->create([
            'company_id' => $this->company->id,
            'name' => 'Acme Parts',
        ]);
        Product::factory()->create([
            'company_id' => $this->company->id,
            'supplier_id' => $acme->id,
            'quantity' => 3,
            'buying_price' => 400,
        ]);
        Product::factory()->create([
            'company_id' => $this->company->id,
            'supplier_id' => null,
            'quantity' => 2,
            'buying_price' => 100,
        ]);

        $this->actingAs($this->owner, 'sanctum')
            ->getJson('/api/app/reports/suppliers')
            ->assertOk()
            ->assertJsonPath('data.kpis.supplier_count', 1)
            ->assertJsonPath('data.kpis.stock_value_cents', 1400)
            ->assertJsonPath('data.rows.0.supplier_name', 'Acme Parts')
            ->assertJsonPath('data.rows.0.stock_value_cents', 1200);
    }

    public function test_another_company_cannot_see_these_reports(): void
    {
        $this->issuePaid('factura', 'Adeel');

        $other = Company::factory()->create();
        Subscription::factory()->create(['company_id' => $other->id]);
        $intruder = User::factory()->businessAdmin()->create(['company_id' => $other->id]);

        $this->actingAs($intruder, 'sanctum')
            ->getJson('/api/app/reports/sales')
            ->assertOk()
            ->assertJsonPath('data.kpis.document_count', 0)
            ->assertJsonPath('data.kpis.total_cents', 0);
    }

    public function test_unknown_kind_is_not_found(): void
    {
        $this->actingAs($this->owner, 'sanctum')
            ->getJson('/api/app/reports/purchases')
            ->assertNotFound();
    }

    public function test_documents_lists_one_kind_inside_the_dates(): void
    {
        $day = now()->toIso8601String();
        $lastMonth = now()->subMonthNoOverflow()->endOfMonth();

        $inside = $this->issuePaid('factura', 'In range', ['issued_at' => $day]);
        $this->issuePaid('factura', 'Before', ['issued_at' => $lastMonth->toIso8601String()]);
        $this->issuePaid('proforma', 'Other kind', ['issued_at' => $day]);
        $voided = $this->issuePaid('factura', 'Voided', ['issued_at' => $day]);
        $this->actingAs($this->owner, 'sanctum')
            ->postJson('/api/app/sales/'.$voided.'/void', ['reason' => 'Client returned the order'])
            ->assertOk();

        $from = now()->startOfMonth()->toDateString();
        $to = now()->endOfMonth()->toDateString();

        $this->actingAs($this->owner, 'sanctum')
            ->getJson("/api/app/reports/documents?type=factura&from={$from}&to={$to}")
            ->assertOk()
            ->assertJsonPath('data.total', 1)
            ->assertJsonPath('data.truncated', false)
            ->assertJsonPath('data.sum_cents', 1210)
            ->assertJsonPath('data.items.0.id', $inside)
            ->assertJsonPath('data.items.0.client_name', 'In Range');

        $this->actingAs($this->owner, 'sanctum')
            ->getJson("/api/app/reports/documents?type=factura&from={$from}&to={$to}&include_voided=1")
            ->assertOk()
            ->assertJsonPath('data.total', 2)
            ->assertJsonPath('data.items.1.voided', true);
    }

    public function test_documents_needs_the_view_permission_of_that_kind(): void
    {
        $member = User::factory()->create([
            'company_id' => $this->company->id,
            'permissions' => ['reports.view', 'proformas.view'],
        ]);

        $this->actingAs($member, 'sanctum')
            ->getJson('/api/app/reports/documents?type=factura&from='.now()->startOfMonth()->toDateString().'&to='.now()->endOfMonth()->toDateString())
            ->assertForbidden();

        $this->actingAs($member, 'sanctum')
            ->getJson('/api/app/reports/documents?type=proforma&from='.now()->startOfMonth()->toDateString().'&to='.now()->endOfMonth()->toDateString())
            ->assertOk();
    }

    public function test_documents_ignores_other_companies(): void
    {
        $this->issuePaid('factura', 'Mine', ['issued_at' => now()->toIso8601String()]);

        $other = Company::factory()->create();
        Subscription::factory()->create(['company_id' => $other->id]);
        $stranger = User::factory()->businessAdmin()->create(['company_id' => $other->id]);

        $this->actingAs($stranger, 'sanctum')
            ->getJson('/api/app/reports/documents?type=factura&from='.now()->startOfMonth()->toDateString().'&to='.now()->endOfMonth()->toDateString())
            ->assertOk()
            ->assertJsonPath('data.total', 0);
    }

    public function test_stock_rows_carry_what_the_import_sheet_needs(): void
    {
        $supplier = Supplier::factory()->create(['company_id' => $this->company->id]);
        Product::factory()->outOfStock()->create([
            'company_id' => $this->company->id,
            'supplier_id' => $supplier->id,
            'short_code' => 'LMP-1',
            'selling_price' => 1500,
            'iva_percent' => 21,
        ]);

        $this->actingAs($this->owner, 'sanctum')
            ->getJson('/api/app/reports/stock')
            ->assertOk()
            ->assertJsonPath('data.rows.0.short_code', 'LMP-1')
            ->assertJsonPath('data.rows.0.supplier', $supplier->name)
            ->assertJsonPath('data.rows.0.selling_price_cents', 1500)
            ->assertJsonPath('data.rows.0.iva_percent', 21);
    }

    /**
     * @param  array<string, mixed>  $extra
     */
    private function issuePaid(string $type, string $clientName, array $extra = []): int
    {
        return $this->issue($type, $clientName, array_merge([
            'payment_status' => 'paid',
            'payment_method_id' => $this->cashId(),
        ], $extra));
    }

    private function issuePending(string $type, string $clientName): int
    {
        return $this->issue($type, $clientName);
    }

    /**
     * @param  array<string, mixed>  $extra
     */
    private function issue(string $type, string $clientName, array $extra = []): int
    {
        $lines = $extra['lines'] ?? [[
            'article' => 'Walk-in item',
            'quantity' => 1,
            'unit_price' => 1000,
            'discount_percent' => 0,
            'iva_percent' => 21,
        ]];
        unset($extra['lines']);

        return (int) $this->actingAs($this->owner, 'sanctum')
            ->postJson('/api/app/sales', array_merge([
                'type' => $type,
                'issued_at' => now()->toIso8601String(),
                'payment_status' => 'pending',
                'save_customer' => false,
                'client_name' => $clientName,
                'lines' => $lines,
            ], $extra))
            ->assertCreated()
            ->json('data.id');
    }

    private function cashId(): int
    {
        return (int) CompanyPaymentMethod::query()->where('name', 'Cash')->value('id');
    }

    private function cardId(): int
    {
        return (int) CompanyPaymentMethod::query()->where('name', 'Card')->value('id');
    }
}
