<?php

namespace App\Http\Controllers\Api\App;

use App\Http\Controllers\Controller;
use App\Http\Resources\SupplierBillResource;
use App\Models\Supplier;
use App\Models\SupplierBill;
use App\Models\SupplierBillPayment;
use App\Services\SupplierLedger;
use App\Traits\ApiResponse;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

/** The supplier ledger: a record book of what was bought from each supplier and what was paid for it. */
class SupplierLedgerController extends Controller
{
    use ApiResponse;

    public function __construct(private readonly SupplierLedger $ledger) {}

    public function index(Request $request): JsonResponse
    {
        $filters = $request->validate([
            'search' => ['nullable', 'string', 'max:120'],
            'supplier_id' => ['nullable', 'integer'],
            'from' => ['nullable', 'date'],
            'to' => ['nullable', 'date'],
            'status' => ['nullable', Rule::in(['all', 'active', 'voided'])],
            'payment' => ['nullable', Rule::in(['all', 'unpaid', 'partial', 'paid'])],
            'per_page' => ['nullable', 'integer', 'min:1', 'max:100'],
        ]);

        $query = SupplierBill::query()
            ->when($filters['supplier_id'] ?? null, fn (Builder $q, $id) => $q->where('supplier_id', $id))
            ->when($filters['from'] ?? null, fn (Builder $q, $date) => $q->whereDate('bill_date', '>=', $date))
            ->when($filters['to'] ?? null, fn (Builder $q, $date) => $q->whereDate('bill_date', '<=', $date))
            ->when(($filters['status'] ?? 'all') === 'active', fn (Builder $q) => $q->whereNull('voided_at'))
            ->when(($filters['status'] ?? 'all') === 'voided', fn (Builder $q) => $q->whereNotNull('voided_at'))
            // Cancelled entries are not owed, so a payment filter looks at the active ones only.
            ->when(in_array($filters['payment'] ?? 'all', ['unpaid', 'partial', 'paid'], true), function (Builder $q) use ($filters) {
                $q->whereNull('voided_at');
                match ($filters['payment']) {
                    'unpaid' => $q->where('paid_cents', 0)->whereColumn('amount_cents', '>', 'paid_cents'),
                    'partial' => $q->where('paid_cents', '>', 0)->whereColumn('amount_cents', '>', 'paid_cents'),
                    'paid' => $q->whereColumn('paid_cents', '>=', 'amount_cents'),
                };
            })
            ->when($filters['search'] ?? null, function (Builder $q, string $search) {
                $like = '%'.$search.'%';
                $q->where(function (Builder $inner) use ($like) {
                    $inner->where('number', 'like', $like)
                        ->orWhere('supplier_name', 'like', $like)
                        ->orWhere('description', 'like', $like)
                        ->orWhere('reference', 'like', $like);
                });
            });

        $page = (clone $query)
            ->orderByDesc('bill_date')
            ->orderByDesc('id')
            ->paginate($filters['per_page'] ?? 10);

        $monthStart = now()->startOfMonth()->toDateString();
        $active = SupplierBill::query()->whereNull('voided_at');

        return $this->success([
            'items' => SupplierBillResource::collection($page->getCollection()),
            'meta' => [
                'current_page' => $page->currentPage(),
                'last_page' => $page->lastPage(),
                'per_page' => $page->perPage(),
                'total' => $page->total(),
            ],
            'stats' => [
                // Everything still owed, whatever the month; and this month's entries and payments.
                'owed_cents' => (int) (clone $active)->whereColumn('amount_cents', '>', 'paid_cents')->sum(DB::raw('amount_cents - paid_cents')),
                'month_bought_cents' => (int) (clone $active)->where('bill_date', '>=', $monthStart)->sum('amount_cents'),
                'month_paid_cents' => (int) SupplierBillPayment::query()
                    ->whereHas('bill', fn (Builder $bill) => $bill->whereNull('voided_at'))
                    ->where('paid_on', '>=', $monthStart)
                    ->sum('amount_cents'),
                'open_count' => (clone $active)->whereColumn('amount_cents', '>', 'paid_cents')->count(),
            ],
        ]);
    }

    public function show(SupplierBill $bill): JsonResponse
    {
        return $this->success(new SupplierBillResource($bill->load(['payments.paymentMethod', 'payments.author:id,name', 'creator:id,name'])));
    }

    public function store(Request $request): JsonResponse
    {
        $companyId = (int) $request->user()->company_id;

        $data = $request->validate([
            'supplier_id' => ['required', 'integer', Rule::exists('suppliers', 'id')->where('company_id', $companyId)],
            'bill_date' => ['required', 'date', 'before_or_equal:today'],
            'description' => ['required', 'string', 'min:2', 'max:500'],
            'reference' => ['nullable', 'string', 'max:60'],
            'notes' => ['nullable', 'string', 'max:2000'],
            'amount_cents' => ['required', 'integer', 'min:1', 'max:999999999999'],
            // What was paid when it was written down (0 or missing = nothing yet); the rest is paid later.
            'paid_cents' => ['nullable', 'integer', 'min:0', 'max:999999999999'],
            'payment_method_id' => ['nullable', 'integer'],
        ]);

        $bill = $this->ledger->record($request->user(), $data);

        return $this->success(new SupplierBillResource($bill), __('Entry saved.'), 201);
    }

    public function addPayment(Request $request, SupplierBill $bill): JsonResponse
    {
        $data = $request->validate([
            'amount_cents' => ['required', 'integer', 'min:1', 'max:999999999999'],
            'paid_on' => ['required', 'date', 'before_or_equal:today'],
            'payment_method_id' => ['required', 'integer'],
            'note' => ['nullable', 'string', 'max:255'],
        ]);

        return $this->success(new SupplierBillResource($this->ledger->addPayment($request->user(), $bill, $data)), __('Payment saved.'), 201);
    }

    public function removePayment(SupplierBill $bill, SupplierBillPayment $payment): JsonResponse
    {
        return $this->success(new SupplierBillResource($this->ledger->removePayment($bill, $payment)), __('Payment removed.'));
    }

    public function void(Request $request, SupplierBill $bill): JsonResponse
    {
        $data = $request->validate(['reason' => ['required', 'string', 'min:3', 'max:255']]);

        return $this->success(new SupplierBillResource($this->ledger->void($request->user(), $bill, $data['reason'])), __('Entry cancelled.'));
    }

    /** Every supplier with entries: what was bought, what was paid and what is still owed. Who is owed most comes first. */
    public function suppliers(): JsonResponse
    {
        $rows = SupplierBill::query()
            ->whereNull('voided_at')
            ->whereNotNull('supplier_id')
            ->groupBy('supplier_id')
            ->selectRaw('supplier_id, COUNT(*) as entries_count, SUM(amount_cents) as bought_cents, SUM(paid_cents) as paid_cents, MAX(supplier_name) as supplier_name')
            ->get()
            ->map(fn ($row) => [
                'supplier_id' => (int) $row->supplier_id,
                'supplier_name' => $row->supplier_name,
                'entries_count' => (int) $row->entries_count,
                'bought_cents' => (int) $row->bought_cents,
                'paid_cents' => (int) $row->paid_cents,
                'owed_cents' => max(0, (int) $row->bought_cents - (int) $row->paid_cents),
            ])
            ->sortByDesc('owed_cents')
            ->values();

        return $this->success($rows);
    }

    /** One supplier's account: every active entry with the payments made, newest first. */
    public function statement(Supplier $supplier): JsonResponse
    {
        $bills = SupplierBill::query()
            ->where('supplier_id', $supplier->id)
            ->whereNull('voided_at')
            ->with(['payments.paymentMethod'])
            ->orderByDesc('bill_date')
            ->orderByDesc('id')
            ->limit(300)
            ->get();

        return $this->success([
            'supplier' => ['id' => $supplier->id, 'name' => $supplier->name, 'code' => $supplier->code],
            'bought_cents' => (int) $bills->sum('amount_cents'),
            'paid_cents' => (int) $bills->sum('paid_cents'),
            'owed_cents' => (int) $bills->sum(fn (SupplierBill $bill) => $bill->owedCents()),
            'entries' => SupplierBillResource::collection($bills),
        ]);
    }
}
